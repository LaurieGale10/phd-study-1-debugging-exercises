# Initial description
#This program inputs the user's first name, surname, and their date of birth and prints a sentence to the screen with their full name and their age.
#If a user's first name is Jo, their last name is Bloggs, and date of birth is 2008, it would print: "Your name is Jo Bloggs and at the end of this year, you will be 15."
#Number of errors: 6

input("What is your first name: ") = first_name
input("What is your last name: ") = last_name
input("What year is your date of birth: ") = DOB

    age = 2023-int(DOB)
print("Your name is "+first_name+last_name+" and at the end of this year you will be age")

#Errors: 3 errors regarding incorrect variable assignment
#Unnecessary indent on line 10
#2 errors in print statement: Should be a space between first_name and last_name and the string "age" will be printed rather than the variable