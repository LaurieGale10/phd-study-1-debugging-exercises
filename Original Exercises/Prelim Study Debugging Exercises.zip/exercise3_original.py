# Initial description
#This program checks if someone should apply to be a computing teacher by checking if they are aged 21 or over, and if they have a passion for teaching computing.
#This program has 5 errors.

print("This program will check if you should apply to be a computing teacher")
age = int(input("What is your age? "))
computing_degree = input("Do you have a passion for teaching computing? Enter 'yes' or 'no': ")

if age > 21 or computing_degree = "Yes":
    allowed_to_apply = "Successful"
else:
    allowed_to_apply = "Unsuccessful"
    print("Result of check: "+allowed_to_apply)

#Errors:
# age>21 should be age>=21
# Should be a double equals on line 9 when checking the value of the string
# "Yes" should technically be "yes" judging by the question's description
# The or on line 9 should be an and
# Line 13 should not be indented so that the result of the check will always be printed