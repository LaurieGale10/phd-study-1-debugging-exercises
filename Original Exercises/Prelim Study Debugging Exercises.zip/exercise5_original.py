#This program simulates a game of rock, paper, scissors between two players. It randomly generates a choice for each player and works out who the winner is. The winner is then printed to the screen. If the match is a draw, then "The winner is Neither" should be printed.

#This program has 5 errors.
import random

player_1 = random.choice(["Rock","Paper", "Scissors"])
print("Player 1 has chosen "+player_1)
player_2 = random.choice(["Rock","Paper", "Scissors"])
print("Player 2 has chosen "+player_2)

if player_1 == player_2:
    winner = "Neither"
elif player_1 == "Rock" or player_2 == "Scissors":
    winner = "Player 1"
elif player_1 =="Rock" or player_2 == "Paper":
    winner = "Player 1"
elif player_1 == "Scissors" or player_2 == "Paper":
    winner = "Player 1"
elif:
    winner = "Player 2"
    print("The winner is "+winner)

#Errors:
# 3 logical errors on the if statement conditions on lines 13,15, and 17; should be "and" rather than "or"
# Syntax error on line 19; should be "else" rather than "elif"
# The print statement on line 21 should not be indented