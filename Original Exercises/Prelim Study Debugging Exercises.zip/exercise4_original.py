#This program should display the first 12 timestables for the number 6 using a while loop. Fix the errors to make sure it prints properly.
#This program has 4 errors

i="0"
print("The times table for the number 6 is:")
while i<12:
    times_table = 6 * i
    i=i+1
print(times_Table) #Would this be perceived as an indentation error or var used outside of scope?


#Errors:
# TypeError with variable i; should be an integer rather than a string
# i<12 on line 6 should be i<=12
# The print statement on line 9 should be printed so the value is printed after each iteration of the while loop
# NameError on line 9 due to typo in variable name "times_table"