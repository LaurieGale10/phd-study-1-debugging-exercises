# Initial description
# Alex has measured out the dimensions of a cuboid to use for a science experiment. Alex has made a program to calcuate the area of the cuboid and print it to the screen. However, the program contains some errors.
# The height and depth of the cuboid are 25cm and its width is 50cm

#Number of errors: 2

height = depth
weight = 50
depth = 25
area = height * weight * depth
print("The area is +str(area))

#Errors: Use of variable 'depth' before it has been defined (based on misconception that depth can be assigned as it wil eventually equal 25)
#Syntax error with missing quotation in print statement