# Initial description
#This program inputs the user's first name, surname, and the year they were born. It then prints a sentence to the screen with their full name and how old they will be at the end of the year.
#If a user's first name is Jo, their last name is Bloggs, and they were born in 2008, it would print: "Your name is Jo Bloggs and at the end of this year, you will be 15".
#Number of errors: 3

input("What year were you born in? ") = year_born
    age = 2023-int(year_born)
    
first_name = input("What is your first name? ")
last_name = input("What is your last name? ")
print("Your name is",first_name,last_name,"and at the end of this year you will be age")

#Errors: 
#Incorrect variable assignment on line 6
#Unnecessary indent on line 7
#Error in print statement: Should be a space between first_name and last_name and the string "age" will be printed rather than the variable